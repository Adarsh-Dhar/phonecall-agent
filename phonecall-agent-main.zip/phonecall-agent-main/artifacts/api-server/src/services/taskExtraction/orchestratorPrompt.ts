import { generateOrchestratorText, OrchestratorEmptyResponseError } from "../nebiusText";
import { logger } from "../../lib/logger";
import { extractJsonObject } from "../../lib/extractJson";
import { sanitizeExtraction } from "./validate";
import type { ExistingKnowledge, ExistingTask, KnowledgeAction, NewMessage, TaskAction } from "./types";

// ---------------------------------------------------------------------------
// Orchestrator extraction call. Goes through the shared Nebius client
// (services/nebiusText.ts) — timeouts, retries, fallback and metrics live there.
// ---------------------------------------------------------------------------

function resolveTimezone(timezone?: string): string {
  const defaultTz = process.env.DEFAULT_TIMEZONE || "Asia/Kolkata";
  const providedTz = timezone ?? defaultTz;
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: providedTz });
    return providedTz;
  } catch {
    return defaultTz;
  }
}

export function resolveTodayISO(timezone?: string, now = new Date()): string {
  return new Intl.DateTimeFormat("en-CA", { timeZone: resolveTimezone(timezone) }).format(now);
}

/** "+05:30" style offset of `timezone` at `now`. */
export function utcOffsetFor(timezone?: string, now = new Date()): string {
  const tz = resolveTimezone(timezone);
  const part = new Intl.DateTimeFormat("en-US", { timeZone: tz, timeZoneName: "longOffset" })
    .formatToParts(now)
    .find((p) => p.type === "timeZoneName")?.value; // "GMT+05:30" | "GMT"
  const m = part?.match(/GMT([+-]\d{2}:\d{2})/);
  return m ? m[1] : "+00:00";
}

export function buildExtractionPrompt(timezone?: string, now = new Date()): string {
  const tz = resolveTimezone(timezone);
  const todayISO = resolveTodayISO(tz, now);
  const offset = utcOffsetFor(tz, now);

  return `Today's date is ${todayISO} in the owner's timezone ${tz} (UTC${offset}). When resolving partial or relative dates (e.g. "7th of September", "next Monday"), always use this date as the reference and infer the correct year.

You review a conversation between the OWNER (the person who uses this app) and their Phone Agent assistant, which talks to an external CONTACT on the owner's behalf.
Each message has a "speaker" label and a "source" (phone_call or app_chat). The label starts with who it is:
  - "owner":   the app user. Their requests are tasks for the agent.
  - "agent":   the Phone Agent speaking for the owner.
  - "contact": the external person/business on the other side of the call or email.
A request made by the contact is NOT a task for the owner unless the owner or the agent explicitly agreed to do it. Do not blame or assign the contact's own requests to the owner.

Your job: identify two types of things from the new messages:

1. TASKS — actionable items the agent needs to do or follow up on, or that the owner is waiting on.
2. KNOWLEDGE — durable facts about this contact/business worth remembering for FUTURE conversations: hours, preferred contact method, account/reference numbers, past issues, stated preferences, constraints. Do NOT extract one-off task details here — those belong in taskActions.

Note: you do NOT generate questions/queries for the owner here. Queries are raised in a separate, dedicated flow. Do not attempt to replicate it.

Given the new messages, the existing open tasks and the facts already known about this contact, return a JSON object with two keys: "taskActions" and "knowledgeActions".

TASK action types:
  - "create":   a new task not covered by an existing one
  - "update":   new info changes an existing task (new due date, clarification, more detail)
  - "complete": the conversation shows an existing task is now resolved
  - "cancel":   the conversation shows an existing task no longer applies

KNOWLEDGE action types:
  - "upsert":     a new or updated durable fact
  - "invalidate": an existing fact (one listed under "Known facts") that is no longer true

Rules for tasks:
- For "update", "complete", "cancel" — taskId MUST be copied exactly from the existing open tasks list. Never invent an id. If no existing task matches, use "create" or do nothing.
- Do not create a task that duplicates an existing open task; use "update" instead.
- confidence is a float 0.0–1.0 reflecting certainty. Use >= 0.9 for complete/cancel/update only when the messages clearly state it.
- kind (REQUIRED on create). Pick the FIRST that matches:
  1 appointment: the business CONFIRMED a specific slot the owner must attend or be reachable at. Not a proposal ("maybe Tuesday"), not the phone call itself. Put the reference/location in meta.
  2 bring: a document or item must be carried or prepared for an appointment. Needs a parent (parentTaskId or parentRef); without one, skip it. One task per call, items in meta.items[].
  3 pay: the owner owes money with a stated deadline or amount (deposit, advance, bill). "Pay at the counter" is NOT pay: put it in the appointment's meta.payAtVisit.
  4 submit: the owner must file, upload, sign or send something by a deadline, and it cannot be done by phone.
  5 follow_up: the BUSINESS promised to act (callback, quote, refund, delivery) and the owner is waiting.
  6 call: the agent should contact the business and the next move is OURS. If the business owes the next step, use follow_up.
  7 reminder: only if the owner personally asked to be reminded. Never from the contact's speech.
  8 other: never choose this yourself.
  One utterance yields at most one main task plus its children.
- A requirement the CONTACT states becomes bring/pay/submit only if the agent accepted it or it is a precondition of the confirmed appointment.
- dueDate: appointment/call/bring/reminder need date, time and offset. pay/submit/follow_up may be a date only (YYYY-MM-DD). bring inherits its parent's time.
- ref: a short label ("a1") on an appointment you create, so children in the same batch can set parentRef="a1".
- sourceMessageIds is the array of message IDs from new_messages that support this action. It must not be empty.

Rules for knowledge:
- key must be a short, stable snake_case label (e.g. "preferred_contact_time").
- If a fact under "Known facts" already covers the same thing, REUSE its exact key so it overwrites instead of duplicating. If the new messages contradict a known fact, upsert the same key with the new value (or "invalidate" it if nothing replaces it).
- "invalidate" may only target a key that appears under "Known facts".
- category is one of: preference | fact | history | constraint | contact_info
- Only extract facts likely to matter in a future, unrelated conversation.

Return ONLY valid JSON — no markdown fences, no explanation.

JSON schema:
{
  "taskActions": [
    {
      "type": "create" | "update" | "complete" | "cancel",
      "taskId": "<string, required for update/complete/cancel>",
      "title": "<string, required for create; optional for update>",
      "description": "<string, optional>",
      "dueDate": "<ISO 8601 with UTC offset, or YYYY-MM-DD for pay/submit/follow_up, optional>",
      "priority": "low" | "normal" | "high",
      "kind": "appointment" | "bring" | "pay" | "submit" | "follow_up" | "call" | "reminder",
      "ref": "<optional>", "parentTaskId": "<existing id, optional>", "parentRef": "<ref in this batch, optional>",
      "meta": { "items": ["..."], "amount": 0, "currency": "INR", "ref": "...", "location": "...", "payAtVisit": "..." },
      "confidence": <number 0-1>,
      "sourceMessageIds": ["<messageId>", ...]
    }
  ],
  "knowledgeActions": [
    {
      "type": "upsert" | "invalidate",
      "category": "preference" | "fact" | "history" | "constraint" | "contact_info",
      "key": "<stable snake_case label>",
      "value": "<string, required for upsert>",
      "confidence": <number 0-1>,
      "sourceMessageIds": ["<messageId>", ...]
    }
  ]
}`;
}

export function buildExtractionUserContent(context: {
  contactName: string;
  contactBusiness: string | null;
  existingTasks: ExistingTask[];
  existingKnowledge: ExistingKnowledge[];
  newMessages: NewMessage[];
  lastCall?: { outcome: string; outcomeSummary?: string; confirmedAt?: Date; confirmationRef?: string; taskId?: string };
}): string {
  const callBlock = context.lastCall
    ? `\nCALL RESULT (already applied, do not recreate):\noutcome: ${context.lastCall.outcome}\nsummary: ${context.lastCall.outcomeSummary ?? ""}\nconfirmedAt: ${context.lastCall.confirmedAt?.toISOString() ?? "none"}\nref: ${context.lastCall.confirmationRef ?? "none"}\ngoal task: ${context.lastCall.taskId ?? "none"}\n`
    : "";
  return `Contact: ${context.contactName} (${context.contactBusiness ?? ""})

Existing open tasks:
${context.existingTasks.length === 0 ? "(none)" : JSON.stringify(context.existingTasks, null, 2)}

Known facts about this contact:
${context.existingKnowledge.length === 0 ? "(none)" : JSON.stringify(context.existingKnowledge, null, 2)}
${callBlock}
New messages to analyse:
${JSON.stringify(context.newMessages, null, 2)}

Return the JSON object with taskActions and knowledgeActions now.`;
}

/**
 * Parse + validate a model reply. Throws SyntaxError on unreadable output.
 * The error never contains the reply text (it may be a call transcript).
 */
export function parseExtractionReply(raw: string) {
  return sanitizeExtraction(extractJsonObject(raw));
}

const NOTHING = () => ({ taskActions: [] as TaskAction[], knowledgeActions: [] as KnowledgeAction[] });

export async function callOrchestratorExtraction(context: {
  /** For log correlation only — never sent to the model. */
  conversationId: string;
  contactName: string;
  contactBusiness: string | null;
  existingTasks: ExistingTask[];
  existingKnowledge?: ExistingKnowledge[];
  newMessages: NewMessage[];
  timezone?: string;
}): Promise<{ taskActions: TaskAction[]; knowledgeActions: KnowledgeAction[] }> {
  let reply: Awaited<ReturnType<typeof generateOrchestratorText>>;
  try {
    reply = await generateOrchestratorText({
      purpose: "extraction",
      systemInstructionText: buildExtractionPrompt(context.timezone),
      turns: [
        {
          role: "user",
          content: buildExtractionUserContent({ ...context, existingKnowledge: context.existingKnowledge ?? [] }),
        },
      ],
      temperature: 0.2,
      maxTokens: 8192,
      jsonResponse: true,
    });
  } catch (err) {
    // A genuinely empty reply means "nothing to extract". A reasoning-only or
    // cut-off reply, and every provider failure, must NOT advance the cursor.
    if (err instanceof OrchestratorEmptyResponseError && err.reason === "empty") return NOTHING();
    throw err;
  }

  if (reply.finishReason === "length") {
    // Incomplete JSON is a failure, not "nothing to extract".
    throw new OrchestratorEmptyResponseError("truncated");
  }

  try {
    const { taskActions, knowledgeActions, dropped } = parseExtractionReply(reply.text);
    if (dropped > 0) logger.warn({ conversationId: context.conversationId, dropped }, "extraction: invalid model actions dropped");
    return { taskActions, knowledgeActions };
  } catch (e) {
    // Metadata only: the raw reply can contain the transcript.
    logger.error(
      { conversationId: context.conversationId, rawChars: reply.text.length, errorName: (e as Error).name },
      "extraction: could not parse model output",
    );
    if (process.env.LOG_LLM_RAW === "1") {
      logger.debug({ conversationId: context.conversationId, rawPreview: reply.text.slice(0, 500) }, "extraction: raw model output (LOG_LLM_RAW)");
    }
    // Rethrow (generic message, no transcript): the cursor must stay put so the
    // delta is retried; runExtraction skips it after MAX_DELTA_FAILURES.
    throw e;
  }
}
