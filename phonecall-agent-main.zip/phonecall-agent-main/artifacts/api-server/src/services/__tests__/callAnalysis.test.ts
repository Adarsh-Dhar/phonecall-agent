import { describe, it, expect } from 'vitest';
import { buildCallTimeContext, buildAgentCallSystemInstruction } from '../callAnalysis';

describe('callAnalysis', () => {
  it('buildCallTimeContext gives the right date for a fixed now in Asia/Kolkata', () => {
    const fixedNow = new Date('2026-10-08T10:30:00Z'); // 4:00 PM IST
    const context = buildCallTimeContext('Asia/Kolkata', fixedNow);

    expect(context).toContain('Thursday, October 8, 2026');
    expect(context).toContain('4:00 PM');
    expect(context).toContain('(India Standard Time)');
  });

  it('buildCallTimeContext handles different timezones', () => {
    const fixedNow = new Date('2026-10-08T10:30:00Z');
    const context = buildCallTimeContext('America/New_York', fixedNow);

    expect(context).toContain('6:30 AM');
    expect(context).toContain('(Eastern Daylight Time)');
  });

  it('buildAgentCallSystemInstruction with no ownerInfo returns the same text as before', () => {
    const result = buildAgentCallSystemInstruction({
      individualName: 'John Doe',
      businessName: 'Acme Corp',
      direction: 'outbound',
      knowledgeFacts: [],
      taskContext: null,
      timezone: 'Asia/Kolkata',
      ownerInfo: [],
    });
    expect(result).toContain('John Doe');
    expect(result).toContain('Acme Corp');
    expect(result).toContain('You are Phone Agent');
  });
});
