import { prisma } from "@workspace/db-prisma";
import { logger } from "../lib/logger";
import { generateOrchestratorText } from "./nebiusText";

/**
 * Get or create the active conversation for a contact.
 * Returns the most recently updated conversation, or creates a new one if none exists.
 * 
 * @param contactId - The contact ID
 * @param titlePrefix - Prefix for the conversation title (e.g., "Email with")
 * @param contactName - Name of the contact for the title
 * @param newContentPreview - Optional preview of new content to check for topic continuation
 */
export async function getOrCreateActiveConversation(
  contactId: string,
  titlePrefix: string,
  contactName: string,
  newContentPreview?: string
) {
  let conversation = await prisma.conversation.findFirst({
    where: { contactId },
    orderBy: { updatedAt: "desc" },
  });

  if (!conversation) {
    conversation = await prisma.conversation.create({
      data: {
        contactId,
        title: `${titlePrefix} ${contactName}`,
      },
    });
    return conversation;
  }

  // If the latest conversation is active, reuse it
  if (conversation.status === "active") {
    return conversation;
  }

  // If the latest conversation is ended and new content was supplied,
  // check if this is a continuation of the same topic
  if (conversation.status === "ended" && newContentPreview) {
    const isContinuation = await classifyTopicContinuation(
      newContentPreview,
      conversation.topicSummary || ""
    );

    if (isContinuation) {
      // Reopen the ended conversation
      conversation = await prisma.conversation.update({
        where: { id: conversation.id },
        data: {
          status: "active",
          endedAt: null,
        },
      });
      logger.info(
        { conversationId: conversation.id, contactId },
        "conversations: reopened ended conversation for topic continuation"
      );
      return conversation;
    }

    // Different topic - create a new conversation
    conversation = await prisma.conversation.create({
      data: {
        contactId,
        title: `${titlePrefix} ${contactName}`,
      },
    });
    logger.info(
      { conversationId: conversation.id, contactId },
      "conversations: created new conversation for different topic"
    );
    return conversation;
  }

  // Latest conversation is ended but no new content supplied
  // Fall back to reusing it
  if (conversation.status === "ended") {
    conversation = await prisma.conversation.update({
      where: { id: conversation.id },
      data: {
        status: "active",
        endedAt: null,
      },
    });
    logger.info(
      { conversationId: conversation.id, contactId },
      "conversations: reopened ended conversation (no content preview)"
    );
  }

  return conversation;
}

/**
 * Classify whether new content is a continuation of a previous topic.
 * Uses the orchestrator model to compare the new content against the previous topic summary.
 * Fails safe toward "continuation" on error.
 */
async function classifyTopicContinuation(
  newContent: string,
  previousTopicSummary: string
): Promise<boolean> {
  if (!previousTopicSummary) {
    // No previous summary, assume continuation
    return true;
  }

  try {
    const { text } = await generateOrchestratorText({
      systemInstructionText: `You are a conversation topic classifier. Determine if the new content is a continuation of the previous topic or a completely different topic.`,
      turns: [
        {
          role: "user",
          content: `Previous topic summary: "${previousTopicSummary}"

New content: "${newContent}"

Respond with only "continuation" or "new_topic".`,
        },
      ],
      temperature: 0,
      maxTokens: 16,
      purpose: "topic_classifier",
    });

    // Only an explicit "new_topic" splits the conversation; anything else
    // ("Continuation.", odd phrasing) keeps the safe default.
    return !/\bnew[_\s-]?topic\b/i.test(text);
  } catch (error) {
    logger.error({ error }, "conversations: topic classification failed, defaulting to continuation");
    // Fail safe: assume continuation on error
    return true;
  }
}

/**
 * End a conversation by marking it as ended and generating a topic summary.
 */
export async function endConversation(conversationId: string) {
  const topicSummary = await summarizeConversationTopic(conversationId);

  const conversation = await prisma.conversation.update({
    where: { id: conversationId },
    data: {
      status: "ended",
      endedAt: new Date(),
      topicSummary,
    },
  });

  logger.info(
    { conversationId, topicSummary },
    "conversations: conversation ended"
  );

  return conversation;
}

/**
 * Generate a topic summary for a conversation using the orchestrator model.
 */
async function summarizeConversationTopic(conversationId: string): Promise<string> {
  try {
    const messages = await prisma.message.findMany({
      where: { conversationId },
      orderBy: { createdAt: "asc" },
      take: 50, // Limit to recent messages to avoid token limits
    });

    if (messages.length === 0) {
      return "No messages";
    }

    const conversationText = messages
      .map((m) => {
        const who = m.role === "assistant" ? "AGENT" : m.callId ? "CONTACT" : "OWNER";
        return `${who}: ${m.content}`;
      })
      .join("\n");

    const { text } = await generateOrchestratorText({
      systemInstructionText: `Summarize the main topic of a conversation in 1-2 sentences (max 100 characters). Focus on what was discussed or accomplished.`,
      turns: [
        {
          role: "user",
          content: `Conversation:
${conversationText}

Topic summary:`,
        },
      ],
      temperature: 0.2,
      maxTokens: 120,
      purpose: "topic_summary",
    });

    return text.trim().slice(0, 100);
  } catch (error) {
    logger.error({ error, conversationId }, "conversations: topic summarization failed");
    return "Conversation ended";
  }
}