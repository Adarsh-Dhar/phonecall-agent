/**
 * Notifications WebSocket — a lightweight, one-directional (server → browser)
 * channel separate from the call transport in voiceStreamBrowser.ts.
 *
 * Currently carries two message types: "call_due" and "call_exhausted", pushed by
 * services/callScheduler.ts when a task's due date arrives or when retry attempts
 * are exhausted. The browser listens on this while the app is open (see
 * hooks/useCallDueNotifications.ts on the frontend) and reacts by auto-opening
 * the call widget for that task or showing an exhausted notification.
 *
 * Delivery targets the owner's open tabs through the presence registry
 * (presence.ts) and falls back to web push (push.ts) when none are connected.
 *
 * DEPRECATED: This file is being replaced by the presence registry system
 * in presence.ts. The broadcastCallDue and broadcastCallExhausted functions now
 * use sendToAccount to target specific users instead of broadcasting to all
 * connected clients.
 */

import { WebSocketServer, WebSocket } from "ws";
import { logger } from "../lib/logger";
import { sendToAccount } from "./presence";
import { sendPushToAccount } from "./push";

const clients = new Set<WebSocket>();

export function createNotificationsStream(): WebSocketServer {
  const wss = new WebSocketServer({ noServer: true });

  wss.on("connection", (ws: WebSocket) => {
    clients.add(ws);
    logger.info({ clientCount: clients.size }, "notifications: client connected");

    ws.on("close", () => {
      clients.delete(ws);
      logger.info({ clientCount: clients.size }, "notifications: client disconnected");
    });

    ws.on("error", (err) => {
      logger.warn({ err }, "notifications: client socket error");
      clients.delete(ws);
    });
  });

  return wss;
}

export type CallDueNotification = {
  type: "call_due";
  taskId: string;
  contactId: string;
  contactName: string;
  title: string;
  description: string | null;
  attempt?: number;
  maxAttempts?: number;
};

/**
 * Sends a call_due notification to the specific account that owns the task.
 * Uses the presence registry to target the right user instead of broadcasting.
 * Falls back to push notifications if the user is offline.
 * Returns true if the notification was delivered, false if delivery failed.
 */
export async function broadcastCallDue(payload: CallDueNotification & { ownerId: string }): Promise<boolean> {
  const delivered = sendToAccount(payload.ownerId, payload);
  if (!delivered) {
    return sendPushToAccount(payload.ownerId, {
      title: "Call due",
      body: `It's time to call about ${payload.title}`,
      url: `/tasks/${payload.taskId}`,
    });
  }
  return delivered;
}

export type CallExhaustedNotification = {
  type: "call_exhausted";
  taskId: string;
  contactId: string;
  contactName: string;
  title: string;
  attempts: number;
  /** "declined" = the business rejected the agent's calls (non-responsive). Absent = could not get through. */
  reason?: "declined";
};

export type TaskDueMessage = {
  type: "task_due";
  taskId: string;
  kind: string;
  title: string;
  dueDate: string | null;
  meta?: unknown;
};

export const PUSH_TITLE: Record<string, string> = {
  appointment: "Appointment coming up",
  bring: "Bring documents",
  pay: "Payment due",
  submit: "Submission due",
  reminder: "Reminder",
  follow_up: "Follow-up due",
  other: "Task due",
};

export async function broadcastTaskDue(task: { id: string; kind: string; title: string; dueDate: Date | null; meta?: unknown, contact: { ownerId: string } }): Promise<boolean> {
  const delivered = sendToAccount(task.contact.ownerId, {
    type: "task_due",
    taskId: task.id,
    kind: task.kind,
    title: task.title,
    dueDate: task.dueDate?.toISOString() ?? null,
    meta: task.meta,
  });
  if (!delivered) {
    return sendPushToAccount(task.contact.ownerId, {
      title: PUSH_TITLE[task.kind] || PUSH_TITLE.other,
      body: task.title,
      url: `/tasks/${task.id}`,
    });
  }
  return delivered;
}

export async function broadcastCallExhausted(
  payload: CallExhaustedNotification & { ownerId: string },
): Promise<boolean> {
  const delivered = sendToAccount(payload.ownerId, payload);
  if (!delivered) {
    return sendPushToAccount(payload.ownerId, {
      title: payload.reason === "declined" ? "Business not responding" : "Could not reach contact",
      body:
        payload.reason === "declined"
          ? `${payload.contactName} rejected ${payload.attempts} call${payload.attempts === 1 ? "" : "s"} about ${payload.title}. Marked non-responsive.`
          : `Couldn't reach ${payload.contactName} about ${payload.title} after ${payload.attempts} attempts`,
      url: `/tasks/${payload.taskId}`,
    });
  }
  return delivered;
}
