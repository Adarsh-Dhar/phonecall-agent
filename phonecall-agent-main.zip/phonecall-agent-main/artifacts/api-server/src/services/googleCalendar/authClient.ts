/**
 * Google OAuth Client Management
 *
 * Loads stored tokens from the Account model (isService: false), refreshes them
 * when expired, and persists refreshed tokens back to the database. Everything
 * else in the googleCalendar service depends on one of these two functions to
 * get an authenticated client.
 */

import { prisma } from "@workspace/db-prisma";
import { google } from "googleapis";
import { logger } from "../../lib/logger";
import {
  GOOGLE_CLIENT_ID,
  GOOGLE_CLIENT_SECRET,
  GOOGLE_REDIRECT_URI,
} from "./config";

/**
 * Get an authenticated OAuth2 client with auto-refresh capabilities for a
 * specific login account. Loads tokens from database, refreshes if expired,
 * and persists new tokens.
 */
export async function getAuthedClient(userId: string): Promise<InstanceType<typeof google.auth.OAuth2> | null> {
  if (!GOOGLE_CLIENT_ID || !GOOGLE_CLIENT_SECRET || !GOOGLE_REDIRECT_URI) {
    logger.warn("Google OAuth credentials not configured");
    return null;
  }

  try {
    logger.info({ userId }, "authClient: attempting to get authenticated client");
    
    let account = await prisma.account.findUnique({
      where: { id: userId },
    });

    if (!account) {
      logger.warn({ userId }, `authClient: no account found with id: ${userId}`);
      return null;
    }

    logger.info({ 
      userId, 
      accountId: account.id, 
      accountName: account.name, 
      isService: account.isService,
      hasRefreshToken: !!account.refreshToken,
      hasAccessToken: !!account.accessToken 
    }, "authClient: found account, checking OAuth tokens");

    // If this is a service account, we need to use the owner's OAuth tokens instead
    // Service accounts (contacts) don't have Google OAuth tokens - only their owners do
    if (account.isService && account.ownerId) {
      const ownerId = account.ownerId;
      logger.info({ 
        serviceAccountId: account.id, 
        ownerId 
      }, "authClient: service account detected, using owner's OAuth tokens");
      
      account = await prisma.account.findUnique({
        where: { id: ownerId },
      });
      
      if (!account) {
        logger.warn({ ownerId }, "authClient: owner account not found");
        return null;
      }
      
      logger.info({ 
        ownerId: account.id, 
        ownerName: account.name, 
        hasRefreshToken: !!account.refreshToken 
      }, "authClient: using owner account for OAuth");
    }

    // If no refresh token, nothing we can do — skip silently
    if (!account.refreshToken) {
      logger.warn({ userId, accountId: account.id, isService: account.isService }, `authClient: no refresh token for account, skipping calendar auth`);
      return null;
    }

    const oauth2Client = new google.auth.OAuth2(
      GOOGLE_CLIENT_ID,
      GOOGLE_CLIENT_SECRET,
      GOOGLE_REDIRECT_URI
    );

    oauth2Client.setCredentials({
      access_token:  account.accessToken ?? undefined,
      refresh_token: account.refreshToken,
      expiry_date:   account.expiryDate?.getTime(),
    });

    // Set up token refresh handler
    oauth2Client.on("tokens", async (tokens) => {
      try {
        logger.info("Google OAuth tokens refreshed, persisting to database");

        // tokens.expiry_date is an absolute epoch-ms timestamp, not a duration.
        const newExpiryDate = new Date(tokens.expiry_date || Date.now() + 3600000);

        await prisma.account.update({
          where: { id: userId },
          data: {
            accessToken: tokens.access_token ?? account.accessToken,
            expiryDate:  newExpiryDate,
          },
        });
      } catch (error) {
        logger.error({ error }, "Failed to persist refreshed Google OAuth tokens");
      }
    });

    // Check if token is expired and refresh if needed
    if (account.expiryDate && account.expiryDate < new Date()) {
      logger.info("Google OAuth token expired, attempting refresh");
      try {
        await oauth2Client.refreshAccessToken();
        logger.info("Google OAuth token refreshed successfully");
      } catch (error) {
        logger.error({ error }, "Failed to refresh Google OAuth token");
        return null;
      }
    }

    return oauth2Client;
  } catch (error) {
    logger.error({ error }, "Failed to get authenticated Google client");
    return null;
  }
}

/**
 * Like getAuthedClient(), but distinguishes *why* no client is available so
 * callers (routes) can return the right HTTP status: 404 when Calendar was
 * never connected, 401 when the stored token is there but refresh failed.
 */
export type AuthedClientResult =
  | { ok: true; client: InstanceType<typeof google.auth.OAuth2> }
  | { ok: false; reason: "not_connected" }
  | { ok: false; reason: "refresh_failed" };

export async function getAuthedClientOrReason(userId: string): Promise<AuthedClientResult> {
  if (!GOOGLE_CLIENT_ID || !GOOGLE_CLIENT_SECRET || !GOOGLE_REDIRECT_URI) {
    return { ok: false, reason: "not_connected" };
  }

  let account = await prisma.account.findUnique({
    where: { id: userId },
  });

  if (!account) {
    logger.warn("Google Calendar not connected - no account found");
    return { ok: false, reason: "not_connected" };
  }

  // If this is a service account, we need to use the owner's OAuth tokens instead
  if (account.isService && account.ownerId) {
    const ownerId = account.ownerId;
    logger.info({ 
      serviceAccountId: account.id, 
      ownerId 
    }, "authClient: service account detected in getAuthedClientOrReason, using owner's OAuth tokens");
    
    account = await prisma.account.findUnique({
      where: { id: ownerId },
    });
    
    if (!account) {
      logger.warn({ ownerId }, "authClient: owner account not found");
      return { ok: false, reason: "not_connected" };
    }
  }

  if (!account.refreshToken) {
    logger.debug("Google Calendar not connected - no refresh token stored");
    return { ok: false, reason: "not_connected" };
  }

  const oauth2Client = new google.auth.OAuth2(
    GOOGLE_CLIENT_ID,
    GOOGLE_CLIENT_SECRET,
    GOOGLE_REDIRECT_URI
  );

  oauth2Client.setCredentials({
    access_token:  account.accessToken ?? undefined,
    refresh_token: account.refreshToken,
    expiry_date:   account.expiryDate?.getTime(),
  });

  // Check if token is expired and refresh if needed
  if (account.expiryDate && account.expiryDate < new Date()) {
    logger.info("Token expired, refreshing...");
    try {
      const { credentials } = await oauth2Client.refreshAccessToken();
      logger.info("Google OAuth token refreshed successfully");

      // credentials.expiry_date is an absolute epoch-ms timestamp, not a duration.
      const newExpiryDate = new Date(credentials.expiry_date || Date.now() + 3600000);

      await prisma.account.update({
        where: { id: userId },
        data: {
          accessToken: credentials.access_token ?? account.accessToken,
          expiryDate:  newExpiryDate,
        },
      });

      // Update the client with the new token
      oauth2Client.setCredentials({
        access_token:  credentials.access_token ?? account.accessToken ?? undefined,
        refresh_token: account.refreshToken,
        expiry_date:   newExpiryDate.getTime(),
      });
    } catch (error) {
      logger.error({ error }, "Failed to refresh Google OAuth token");
      return { ok: false, reason: "refresh_failed" };
    }
  }

  return { ok: true, client: oauth2Client };
}
