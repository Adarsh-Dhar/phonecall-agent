import { apiFetch } from './shared';

// ─── Orchestrator Chat API ────────────────────────────────────────────────────
// Backed by Nebius Token Factory on the server; the route path is /api/orchestrator/chat.

export const sendOrchestratorMessage = async (
  messages: Array<{ role: string; content: string }>,
  contactId?: string,
) => {
  const response = await apiFetch('/api/orchestrator/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ messages, contactId }),
  });
  if (!response.ok) {
    const error = await response.json().catch(() => null);
    throw new Error(error?.error || 'Failed to send message');
  }
  try {
    return await response.json();
  } catch {
    throw new Error('Invalid response from server');
  }
};
