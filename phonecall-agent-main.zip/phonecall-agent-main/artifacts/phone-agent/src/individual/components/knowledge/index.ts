export { KnowledgeBoardPanel } from './KnowledgeBoardPanel';
