import { useEffect, useRef, useState } from 'react';
import * as api from '@/lib/api';

const OUTCOME_META: Record<api.CallOutcome, { label: string; color: string }> = {
  booked: { label: 'Booked', color: 'bg-[#3f8274] text-white' },
  rescheduled: { label: 'Rescheduled', color: 'bg-[#3159c4] text-white' },
  cancelled: { label: 'Cancelled', color: 'bg-[#b44343] text-white' },
  info_gathered: { label: 'Info Gathered', color: 'bg-[#697a73] text-white' },
  needs_user: { label: 'Needs Input', color: 'bg-[#e85d04] text-white' },
  failed: { label: 'Failed', color: 'bg-[#b44343] text-white' },
};

export function CallRow({ call, expanded, onToggle, loadMessages = api.fetchCallMessages }: {
  call: api.Call;
  expanded: boolean;
  onToggle: () => void;
  loadMessages?: (callId: string) => Promise<api.Message[]>;
}) {
  const [callMessages, setCallMessages] = useState<api.Message[]>([]);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const hasLoaded = useRef(false);

  const isInbound = call.direction === 'inbound';
  const statusColor = call.status === 'completed' ? 'text-[#3f8274]' :
                     call.status === 'failed' || call.status === 'no-answer' || call.status === 'busy' ? 'text-[#b44343]' :
                     'text-muted-foreground';
  const outcomeMeta = call.outcome ? OUTCOME_META[call.outcome] : null;

  const loadCallMessages = async () => {
    if (hasLoaded.current) return;
    setLoadingMessages(true);
    try {
      const messages = await loadMessages(call.id);
      setCallMessages(messages);
      hasLoaded.current = true;
    } catch (e) {
      console.error('Failed to load call messages:', e);
    } finally {
      setLoadingMessages(false);
    }
  };

  // Load messages when expanded
  useEffect(() => {
    if (expanded && !hasLoaded.current) {
      void loadCallMessages();
    }
  }, [expanded, call.id]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className="flex flex-col gap-1 rounded-2xl border border-border bg-card p-5 transition-transform hover:-translate-y-0.5">
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <span className={`text-[9px] font-bold uppercase tracking-[.08em] ${isInbound ? 'text-[#3159c4]' : 'text-[#3f8274]'}`}>
              {isInbound ? 'Inbound' : 'Outbound'}
            </span>
            <span className={`text-[10px] ${statusColor}`}>
              {call.status}
            </span>
            {outcomeMeta && (
              <span className={`text-[9px] font-bold uppercase tracking-[.08em] px-2 py-0.5 rounded-full ${outcomeMeta.color}`}>
                {outcomeMeta.label}
              </span>
            )}
          </div>
          <h3 className="mt-1 font-bold">
            {isInbound ? `Inbound call from ${call.contact?.name}` : `Outbound call to ${call.contact?.name}`}
          </h3>
          {call.outcome === 'needs_user' && (
            <div className="mt-1 inline-flex items-center rounded-full bg-[#e85d04] px-2 py-0.5 text-[10px] font-bold text-white">
              Needs your input
            </div>
          )}
          <p className="mt-1 text-xs text-muted-foreground">
            {call.durationSec != null ? `${Math.floor(call.durationSec / 60)}m ${call.durationSec % 60}s` : 'In progress'}
          </p>
          {call.outcomeSummary && (
            <p className="mt-1 text-xs text-muted-foreground italic">{call.outcomeSummary}</p>
          )}
          {(call.confirmationRef || call.confirmedAt) && (
            <p className="mt-1 text-xs text-muted-foreground">
              Confirmation: {call.confirmationRef || new Date(call.confirmedAt!).toLocaleString()}
            </p>
          )}
          {call.recordingUrl && (
            <a href={call.recordingUrl} className="mt-2 text-xs text-[#3159c4] underline">Recording</a>
          )}
        </div>
        <div className="shrink-0 text-right">
          <p className="text-[10px] text-muted-foreground">
            {call.endedAt ? new Date(call.endedAt).toLocaleDateString() :
             call.startedAt ? new Date(call.startedAt).toLocaleDateString() :
             new Date(call.createdAt).toLocaleDateString()}
          </p>
          {call.contact && (
            <div className="mt-2 flex items-center gap-1.5">
              <span
                className="grid h-4 w-4 shrink-0 place-items-center rounded-full text-[8px] font-bold"
                style={{ background: call.contact.color }}
              >
                {call.contact.initials.slice(0, 1)}
              </span>
              <span className="text-[10px] font-bold text-[#3159c4]">{call.contact.name}</span>
            </div>
          )}
          <button
            type="button"
            onClick={onToggle}
            className="mt-2 text-xs text-[#3159c4] hover:underline"
          >
            {expanded ? 'Hide transcript' : 'View transcript'}
          </button>
        </div>
      </div>

      {expanded && (
        <div className="mt-4 pt-4 border-t border-border">
          {loadingMessages ? (
            <div className="text-center text-xs text-muted-foreground">Loading transcript...</div>
          ) : callMessages.length === 0 ? (
            <div className="text-center text-xs text-muted-foreground">No transcript available</div>
          ) : (
            <div className="space-y-3">
              {callMessages.map((message) => {
                const speakerName = message.speakerName || message.speaker || 'Unknown';
                const speakerInitial = speakerName.charAt(0).toUpperCase();
                const isAgent = speakerName.includes('(AI)') || message.speaker === 'agent';
                return (
                  <div key={message.id} className="flex gap-3">
                    <div className={`shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                      isAgent ? 'bg-[#3f8274] text-white' : 'bg-[#697a73] text-white'
                    }`}>
                      {speakerInitial}
                    </div>
                    <div className="flex-1 rounded-lg bg-muted px-3 py-2 text-sm">
                      <p className="text-xs font-bold text-muted-foreground mb-1">
                        {speakerName}
                      </p>
                      <p className="text-foreground">{message.content}</p>
                      <p className="mt-1 text-[10px] text-muted-foreground">{message.time}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
