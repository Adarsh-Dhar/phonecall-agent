# phonecall-agent

## Individuals and businesses

The app supports two account roles with separate frontends and API surfaces:

| Role | Account type | Frontend | API access | AI behavior |
|------|-------------|----------|------------|-------------|
| Individual | `isService: false` | Full app (Calls, Contacts, History, Calendar, Tasks) | All endpoints except `/api/business/*` | AI represents the individual and speaks for them in both call directions |
| Business | `isService: true` | Calls + Contacts only | `/api/business/*` endpoints only | No AI — the business human speaks directly to the individual's AI agent |

### Hard limitations

- Calls are strictly individual ↔ business; same-role calls are rejected.
- Individuals can only add/search business contacts (no fallback across account types).
- Businesses can only add/search individual contacts.
- Individuals cannot access `/api/business/*` (403 Forbidden).
- Businesses cannot access individual-only APIs (403 Forbidden).
- Browser test calls are blocked for business accounts.
- The AI agent always represents the individual, never the business.
- On calls, the individual observes the transcript without speaking; the business human speaks to the individual's AI agent.

### Call party resolution

The `Call` model includes `individualId`, `businessId`, and `initiatedBy` fields to track call parties and direction. Existing calls are backfilled by migration where possible; calls with unresolved parties remain nullable and are rejected by the voice socket.

## Running Tests

Tests run against a real PostgreSQL database. All commands from the **repo root** unless noted.

1. Start the test database: `docker-compose up -d postgres-test`
2. Point at it (the name must end in `_test`):
   `export TEST_DATABASE_URL="postgresql://phoneagent:phoneagent_password@localhost:5435/phone_agent_test"`
3. Apply migrations to the test DB (the `prisma/` folder is at the repo root):
   `DATABASE_URL="$TEST_DATABASE_URL" npx prisma migrate deploy`
4. Check that the new schema landed:
   `docker exec phone-agent-postgres-test psql -U phoneagent -d phone_agent_test -c '\d "PushSubscription"' -c '\d "Call"'`
   (Call must show outcome, outcomeSummary, confirmedAt, confirmationRef, taskId.)
5. Run: `pnpm --filter @workspace/api-server test` and `pnpm typecheck`

`vitest.setup.ts` refuses to run unless `TEST_DATABASE_URL` is set and its database name ends in `_test`,
and it overrides `DATABASE_URL` with it, so tests can never touch your dev or prod database.

## Agent mode (individuals only)

Individual accounts have an **Agent mode** switch (Preferences, `GET/PATCH /api/user/agent-mode`, default off).
When on, the individual's AI agent acts without the owner doing anything:

- **Sends:** when a call task is due (including ones created from Google Calendar), the scheduler dials the linked business itself. With it off, the owner only gets a "call due" notification.
- **Receives:** incoming business calls are answered immediately (no ring), even while the owner is offline.
- **During the call:** the agent never waits for the owner. `ask_user` returns `USER_UNAVAILABLE` at once; the question is saved for the owner and the call ends with outcome `needs_user`.

Business accounts cannot use agent mode (403). The business side of every call is still a human using the app.
`CALL_SCHEDULER_AUTO_DIAL=0` disables agent-placed calls for everyone.

**Note:** The legacy `PATCH /api/user/agent-auto-answer` endpoint is deprecated but kept for backward compatibility. It now redirects to the new `agentMode` field.

### Owner Autonomy (Standing Rules & Handoff)

When agent mode is on, owners can configure **standing rules** that guide the agent's behavior without waiting for questions:

- **Approval rules:** Define when the agent should ask, deny, or handoff for scheduling, money, personal info, or commitments
- **Live handoff:** The agent can request the owner to join a live call when stakes are high (payments, identity checks, insisted requests)
- **Lessons:** The system learns from past calls and suggests improvements for future autonomous behavior
- **Quality scoring:** Each autonomous call is scored (1-100) based on outcome, duration, and resolution
- **Digest:** Owners receive a daily summary of autonomous calls (configurable hour, can be disabled)

These features are managed via:
- `GET/POST/PUT/DELETE /api/agent/rules` - CRUD for approval rules
- `GET/PUT /api/agent/settings` - Digest configuration
- `GET /api/agent/lessons` - View learned lessons
- Preferences UI includes "Standing Rules" section when agent mode is enabled

## Settings

### Scheduler Configuration

- `SCHEDULER_STALE_HOURS` (default: 24) - Hours after which a task is considered stale and won't be triggered
- `SCHEDULER_MAX_ATTEMPTS` (default: 3) - Maximum number of retry attempts for a task notification
- `SCHEDULER_CLAIM_TTL_MS` (default: 300000) - Time in milliseconds after which a stuck claim is released (5 minutes)
- `CALL_SCHEDULER_POLL_MS` (default: 30000) - Poll interval in milliseconds for the call scheduler (30 seconds)

### Timezone Settings

- `DEFAULT_TIMEZONE` (default: Asia/Kolkata) - Default timezone for date/time resolution when user timezone is not set

### Business Hours

Business hours can be set on contacts to control when the scheduler attempts to call them. The format is a JSON object with the following structure:

```json
{
  "days": [1, 2, 3, 4, 5],
  "start": 9,
  "end": 17,
  "tz": "Asia/Kolkata"
}
```

- `days`: Array of day numbers (0 = Sunday, 1 = Monday, ..., 6 = Saturday)
- `start`: Start hour in 24-hour format (0-23)
- `end`: End hour in 24-hour format (0-24, exclusive)
- `tz`: Timezone string (optional, defaults to contact's timezone or DEFAULT_TIMEZONE)

Example: `{"days":[1,2,3,4,5],"start":9,"end":17,"tz":"Asia/Kolkata"}` means Monday through Friday, 9 AM to 5 PM IST.

## Fallback messages

When the agent cannot get through, the owner and (optionally) the business are told.

| Situation | Owner | Business |
|---|---|---|
| Attempts used up, or the final call rings out unanswered | Open tabs, then web push, then **email** (Preferences: "Email me when I can't be reached") | Only if the agent made the call **and** the contact has "Message if unreachable" on |
| Owner was asked to call and did not | Same as above | Never |

Business messages try **email** (needs `contactEmail`), then **WhatsApp** (needs a phone number in
international format plus the `WHATSAPP_*` variables). The first channel that delivers wins.

Safety rules, all enforced in `services/outbound`:
- Off by default; opt-in per contact. The toggle cannot be enabled with no usable channel.
- At most one message per task and two per contact in any 24 hours.
- The text contains only your display name, the contact's name and the task title.
- Every message carries a signed opt-out link (`/api/outbound/opt-out`, also one-click `List-Unsubscribe`). With no `APP_URL` nothing is sent.
- Every attempt (sent or failed) is stored in `OutboundMessage`.
- Replies go to your login email (`Reply-To`), which therefore becomes visible to the business.

Inbound email handling (`/api/emails`) is not part of this codebase.

## Environment Variables

### API Keys

- `GEMINI_API_KEY` - Google Gemini API key for voice processing
- `GEMINI_LIVE_MODEL` - Model to use for live voice calls
- `NEBIUS_API_KEY` - Nebius API key for all orchestrator text calls (task/knowledge extraction, post-call escalation, topic classification/summaries, demo chat)
- `NEBIUS_BASE_URL` - Nebius API base URL
- `NEBIUS_MODEL` - Nebius model to use
- `NEBIUS_FALLBACK_MODEL` - (optional) model used when `NEBIUS_MODEL` is rejected; defaults to `Qwen/Qwen3.5-397B-A17B`
- `LOG_LLM_RAW` - (optional) set to `1` to log a truncated preview of an unparseable extraction response at debug level; off by default because it is derived from call transcripts

### Google Calendar

- `GOOGLE_CLIENT_ID` - Google OAuth client ID
- `GOOGLE_CLIENT_SECRET` - Google OAuth client secret
- `GOOGLE_REDIRECT_URI` - Google OAuth redirect URI
- `GOOGLE_CALENDAR_ID` - Google Calendar ID to sync tasks to

### Push Notifications

- `VAPID_PUBLIC_KEY` - VAPID public key for web push
- `VAPID_PRIVATE_KEY` - VAPID private key for web push
- `VAPID_SUBJECT` - VAPID subject (contact email)

### Other

- `ASK_USER_TIMEOUT_MS` (default: 45000) - Timeout in milliseconds for user response during calls
- `PUBLIC_WS_URL` - Public WebSocket URL for the frontend
